import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-universitis',
  templateUrl: './universitis.component.html',
  styleUrls: ['./universitis.component.css']
})
export class UniversitisComponent implements OnInit {
  countrycode: any;

  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    this.activatedRoute.paramMap.subscribe(param =>{
      this.countrycode=param.get('country')
    })

  }

}
