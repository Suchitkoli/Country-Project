import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CountrydataService } from '../services/countrydata.service';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {

  constructor(private countries:CountrydataService ,private router:Router) { }
  country:Array <any>=new Array()
  maindata:Array <any>=new Array()
  dataInfo:any
  dataManage:any
  ngOnInit(): void {

  //Fetching countries

  this.countries.getcountry().subscribe(data=>{
    console.log("country Data::-", data)
    
    this.country.push(data)
    
    for(let i of this.country)
    {
      console.log("For Loop ::-",i.data)
      this.dataInfo=i.data
      console.log("For Loop Data info ::-",this.dataInfo.AF.country)
   
     


   }
   for(let j of Object.keys(this.dataInfo)){
     var capial=this.dataInfo[j]
    //  console.log("Value of j",capial.country)
     this.maindata.push(capial.country)
   }
   console.log("All countries::--",this.maindata)
   })
    

  }
  countrycode!:string
  getcountry($event:any){
  console.log("Value",$event.target.value)
  this.countrycode=$event.target.value
   this.router.navigate(['universitis',this.countrycode])

  }

}
