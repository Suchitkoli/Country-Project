import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { CountryComponent } from './country/country.component';
import { UniversitisComponent } from './universitis/universitis.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    CountryComponent,
    UniversitisComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'',redirectTo:'Country-List',pathMatch:'full'},
      {path:'Country-List',component:CountryComponent},
      {path:'universitis/:country',component:UniversitisComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
